<?php 
    include("dbconnect.php"); 
    extract($_POST); 
    session_start(); 
 
    // Verify CAPTCHA if login button is clicked
    if(isset($_POST['btn'])) 
    {
        // Check if captcha is set and matches the session value
        if(!isset($_POST['captcha']) || $_POST['captcha'] != $_SESSION['captcha_code']) {
            echo "<script>alert('CAPTCHA verification failed. Please try again.')</script>";
        } else {
            // CAPTCHA passed, now verify login credentials
            $qry = mysqli_query($conn, "SELECT * FROM admin WHERE name='$uname' && psw='$password'"); 
            $num = mysqli_num_rows($qry); 
            
            if($num == 1) 
            { 
                echo "<script>alert('Welcome to admin home page');</script>";
                header("location:adminhome.php"); 
                exit;
            } 
            else 
            { 
                echo "<script>alert('User Name Password Wrong.....')</script>"; 
            } 
        }
    }
    
    // Generate a random CAPTCHA code 
    function generateCaptcha($length = 6) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $captcha = '';
        for ($i = 0; $i < $length; $i++) {
            $captcha .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $captcha;
    }
    
    // Generate and store CAPTCHA code in session
    $captcha_code = generateCaptcha();
    $_SESSION['captcha_code'] = $captcha_code;
?>  

<html> 
<head>
<title>Tours & Travels</title> 
<style> 
#navbar { 
  padding: 25px; 
  background: #1e3c72; 
  background-size: 1420px  100px; 
  text-align:center; 
  text-decoration:blink; 
  color:white; 
   font-family: Arial; 
   font-size:35px; 
} 
 
p 
{ 
    color:white; 
    text-align: center; 
    text-transform: uppercase; 
     font-size:20px; 
} 
 
ul { 
  list-style-type: none; 
  margin: 0; 
  padding: 0; 
  overflow: hidden; 
  background-color: #333; 
  position: sticky; /* Safari */ 
  position: sticky; 
  top: 0; 
} 
 
li { 
  float: left; 
} 
 
li a { 
  display: block; 
  color: white; 
  text-align: center; 
  padding: 14px 16px; 
  text-decoration: none; 
} 
 
li a:hover { 
  background-color:  #1e3c72; 
} 
 
.active { 
  background-color: #1e3c72; 
} 
 
#footer { 
  border: 2px solid rgb(215, 215, 194); 
  padding: 45px; 
  background:#333; 
  background-repeat: no-repeat; 
  background-size: 1420px  100px; 
  border-radius:10px; 
  text-align:center; 
  text-decoration:blink; 
  color:white;
   font-family: Arial; 
   font-size:15px; 
} 
#bg1 { 
 
  padding:150px; 
  background:url("img/2.jpg"); 
  background-repeat: no-repeat;  background-size: 100%  300px; 
  border-radius:5px; 
   border-radius:10px; 
   font-size:35px; 
} 

.captcha-container {
    margin: 10px 0;
    display: flex;
    align-items: center;
}

.captcha-code {
    background-color: #f0f0f0;
    padding: 8px 15px;
    font-family: 'Courier New', monospace;
    font-weight: bold;
    letter-spacing: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
    margin-right: 10px;
    user-select: none;
}
 
</style> 
</head> 
<body>
<div id="navbar"><p>Tours And Travels </p></div> 
<ul> 
     <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li> 
      <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li> 
       <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li> 
        <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li> 
        <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li> 
      <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li> 
      <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a href="index.php">Home Page</a></li> 
  <li><a href="#">&nbsp;</a></li> 
  <li><a class="active" href="admin.php">Admin login</a></li> 
  <li><a href="#">&nbsp;</a></li> 
  <li><a href="user.php">User Login</a></li> 
  <li><a href="#">&nbsp;</a></li> 
  <li><a href="register.php">User Registration</a></li> 
</ul> 
<div id="bg1"> </div> 
<form id="form1" name="form1" method="post" action=""> 
       <table width="46%" border="0" align="center"> 
         <tr> 
           <td colspan="2" rowspan="1"><div align="center" class="style1"><strong><font size="+1">Admin Login</font> </div></td> 
         </tr> 
            <tr> 
        <td width="48%">&nbsp;</td> 
            <td width="52%">&nbsp;</td> 
              </tr> 
         </tr> 
         <tr> 
           <td height="31"align="center"><span class="style2"><strong>User Name </strong></span></td> 
           <td><label> 
             <input name="uname" type="text" id="uname" required /> 
           </label></td> 
         </tr> 
         <tr> 
           <td height="44" align="center"><span class="style2"><strong>Password</strong></span></td> 
           <td><label> 
             <input name="password" type="password" id="password" required /> 
           </label></td> 
         </tr> 
         <tr> 
           <td height="44" align="center"><span class="style2"><strong>CAPTCHA</strong></span></td> 
           <td>
               <div class="captcha-container">
                   <div class="captcha-code"><?php echo $captcha_code; ?></div>
               </div>
               <input name="captcha" type="text" id="captcha" placeholder="Enter the code above" required />
           </td> 
         </tr> 
         <tr> 
           <td>&nbsp;</td> 
           <td rowspan="2"><label> 
             <input name="btn" type="submit" id="btn" value="Login" /> 
             <input type="reset" name="Submit2" value="Cancel" /> 
           </label></td> 
         </tr> 
  </table> 
</form> 
<div> &nbsp;</div> 
<div id="footer"> copyrights & designedby@Tours&travels</div>
</body>
</html>