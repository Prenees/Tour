<?php
include("dbconnect.php");
extract($_POST);
session_start();
if(isset($_POST['btn']))
{
    $file_name=$_FILES['img']['name'];  
    $file_loc=$_FILES['img']['tmp_name'];
    $folder = "upload/";   

    $path=move_uploaded_file($file_loc,$folder.$file_name);
    $img=$file_name;

    $qry=mysqli_query($conn,"insert into package(pname,package_price,place,sdate,edate,img,des)values('$pname','$pp','$place','','$days','$img','$des')");
    if($qry)
    {
        echo "<script>alert('Data Save');</script>";
    }
    else
    {
        echo "<script>alert('Data Not Save');</script>";
    }
}

?>
</table>


<html>
<head>
<title>Tours & Travels</title>
<style>
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

#navbar {
    padding: 25px;
    background: #00ffff;
    background-size: 1500px 100px;
    text-align: center;
    text-decoration: blink;
    color:white;
    font-family: Arial;
    font-size: 35px;
    animation: fadeIn 2s ease-in-out;
}

p {
    color:white;
    text-align: center;
    text-transform: uppercase;
    font-size: 20px;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color:#333;
    position: sticky; /* Safari */
    position: sticky;
    top: 0;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    transition: background-color 0.3s ease;
}

li a:hover {
    background-color: rgb(105, 166, 166);
    transform: scale(1.1);
}

.active {
    background-color:rgb(105, 166, 166);
}

#footer {
    border: 2px solid #888844;
    padding: 45px;
    background:#333;
    background-repeat: no-repeat;
    background-size: 1420px 100px;
    border-radius: 10px;
    text-align: center;
    text-decoration: blink;
    color:white;
    font-family: Arial;
    font-size: 15px;
    animation: fadeIn 2s ease-in-out;
}

#bg1 {
    padding: 150px;
    background: url("img/7.jpg");
    background-repeat: no-repeat;
    background-size: 100% 200px;
    border-radius: 5px;
    font-size: 35px;
    animation: fadeIn 2s ease-in-out;
}
form 
{
    animation: fadeIn 2s ease-in-out;
}

@keyframes slideIn {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

form {
    animation: slideIn 1s ease-in-out;
}
</style>
</head>
<body>
<div id="navbar"><p>Tours And Travels </p></div>
<ul>
    <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
    <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
    <li><a class="active" href="adminhome.php">Home Page</a></li>
    <li><a href="#">&nbsp;</a></li>
    <li><a href="guide.php">Add Guide</a></li>
   <li><a href="#">&nbsp;</a></li>
    <li><a href="transopts.php">Add Transopts</a></li>
    <li><a href="#">&nbsp;</a></li>
    <li><a href="viewu.php">User Details</a></li>
    <li><a href="#">&nbsp;</a></li>
    <li><a href="viewp.php">Packages Details</a></li>
    <li><a href="#">&nbsp;</a></li>
    <li><a href="booking.php">Booking Details</a></li>
    <li><a href="#">&nbsp;</a></li>
    <li><a href="feedback1.php">feedback Details</a></li>
    <li><a href="#">&nbsp;</a></li>
    <li><a href="index.php">LogOut</a></li>
</ul>
<div id="bg1"></div>
<form id="form1" name="form1" method="post" action="" enctype="multipart/form-data">
    <table width="46%" border="0" align="center">
        <tr>
            <td colspan="2" rowspan="1"><div align="center" class="style1"><strong><font size="+1">Add Packages</font> </div></td>
        </tr>
        <tr>
            <td width="48%">&nbsp;</td>
            <td width="52%">&nbsp;</td>
        </tr>
        <tr>
            <td height="31" align="center"><span class="style2"><strong>Package Name </strong></span></td>
            <td><label>
                <input name="pname" type="text" id="pname" />
            </label></td>
        </tr>
        <tr>
            <td height="44" align="center"><span class="style2"><strong>Package Price </strong></span></td>
            <td><label>
                <input name="pp" type="text" id="pp" />
            </label></td>
        </tr>
        <tr>
            <td height="44" align="center"><span class="style2"><strong>Places</strong></span></td>
            <td><label>
                <textarea name="place" type="text"></textarea>
            </label></td>
        </tr>
        <tr>
            <td height="44" align="center"><span class="style2"><strong>Number Of Days</strong></span></td>
            <td><label>
                <input name="days" type="text" id="days" />
            </label></td>
        </tr>
        <tr>
            <td height="44" align="center"><span class="style2"><strong>Images</strong></span></td>
            <td><label>
                <input name="img" type="file" id="img" />
            </label></td>
        </tr>
        <tr>
            <td height="44" align="center"><span class="style2"><strong>Description</strong></span></td>
            <td><label>
                <textarea name="des" id="des"></textarea>
            </label></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td rowspan="2"><label>
                <input name="btn" type="submit" id="btn" value="add" />
                <input type="reset" name="Submit2" value="Cancel" />
            </label></td>
        </tr>
    </table>
</form>
<div> &nbsp;</div>
<div id="footer"> copyrights & designedby@Tours & travels</div>
</body>
</html>