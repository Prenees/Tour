<?php
    include("dbconnect.php");
    extract($_POST);
    session_start();

    // Verify CAPTCHA if login button is clicked
    if(isset($_POST['btn'])) 
    {
        // Check if captcha is set and matches the session value
        if(!isset($_POST['captcha']) || $_POST['captcha'] != $_SESSION['captcha_code']) {
            echo "<script>alert('CAPTCHA verification failed. Please try again.')</script>";
        } else {
            // CAPTCHA passed, now verify login credentials
            $qry = mysqli_query($conn, "SELECT * FROM register WHERE uname='$uname' && psw='$password'");
            $num = mysqli_num_rows($qry);
            
            if($num == 1)
            {
                $qry1 = mysqli_query($conn, "SELECT * FROM register WHERE uname='$uname' && psw='$password'");
                $row = mysqli_fetch_assoc($qry1);
                $_SESSION['id'] = $row['id'];
                echo "<script>alert('welcome to User home page');</script>";
                header("location:userhome.php");
                exit;
            }
            else
            {
                echo "<script>alert('User Name Password Wrong.....')</script>";
            }
        }
    }
    
    // Generate a random CAPTCHA code 
    function generateCaptcha($length = 6) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $captcha = '';
        for ($i = 0; $i < $length; $i++) {
            $captcha .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $captcha;
    }
    
    // Generate and store CAPTCHA code in session
    $captcha_code = generateCaptcha();
    $_SESSION['captcha_code'] = $captcha_code;
?>
<html>
<head>
<title>Tours & Travels - User Login</title>
<style>
/* Background Animation */
@keyframes backgroundAnimation {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

/* Fade-in Animation */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Navbar Styles */
#navbar {
  padding: 10px;
  background: linear-gradient(45deg, #1e3c72, #2a5298);
  background-size: 200% 200%;
  text-align: center;
  color: white;
  font-family: Arial, sans-serif;
  font-size: 35px;
  animation: backgroundAnimation 6s infinite alternate;
}

/* Navigation Menu */
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  background-color: #333;
  display: flex;
  justify-content: center;
}

li {
  float:left;
}

li a {
  display: block;
  color: white;
  text-align:center;
  padding: 14px 16px;
  text-decoration: none;
  transition: all 0.3s ease-in-out;
}

li a:hover {
  background-color: #1e3c72;
  box-shadow: 0 0 15px #1e3c72;
}

/* Slide-in Form */
@keyframes slideIn {
  from { transform: translateY(50px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

form {
  animation: slideIn 1s ease-in-out;
  background: rgba(255, 255, 255, 0.9);
  padding: 100px;
  border-radius: 10px;
  width: 40%;
  margin: auto;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
}

/* Input Styles */
input[type="text"], input[type="password"] {
  width: 100%;
  padding: 10px;
  margin: 5px 0;
  border: 1px solid #ccc;
  border-radius: 5px;
}

/* Button Bounce Effect */
@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-5px); }
}

input[type="submit"], input[type="reset"] {
  padding: 10px 20px;
  border: none;
  cursor: pointer;
  background: #1e3c72;
  color: white;
  font-size: 16px;
  border-radius: 5px;
  animation: bounce 2s infinite;
  transition: transform 0.3s;
}

input[type="submit"]:hover, input[type="reset"]:hover {
  transform: scale(1.1);
  box-shadow: 0 0 15px #1e3c72;
}

/* Footer Pulse Effect */
@keyframes pulse {
  0% { transform: scale(1); }
  50% { transform: scale(1.05); }
  100% { transform: scale(1); }
}

#footer {
  padding: 30px;
  background: #333;
  color: white;
  text-align: center;
  font-size: 15px;
  animation: pulse 3s infinite;
}
.captcha-container {
    margin: 10px 0;
    display: flex;
    align-items: center;
}

.captcha-code {
    background-color: #f0f0f0;
    padding: 8px 15px;
    font-family: 'Courier New', monospace;
    font-weight: bold;
    letter-spacing: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
    margin-right: 10px;
    user-select: none;
}

</style>
</head>
<body>
<div id="navbar"><p>Tours And Travels </p></div>
<ul>
  <li><a href="index.php">Home Page</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="admin.php">Admin login</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a class="active" href="user.php">User Login</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="register.php">User Registration</a></li>
</ul>
<div id="bg1"> </div>
<form id="form1" name="form1" method="post" action="">
       <table width="46%" border="0" align="center">
         <tr>
           <td colspan="2" rowspan="1"><div align="center" class="style1"><strong><font size="+1">User Login</font> </div></td>
         </tr>
            <tr>
        <td width="48%">&nbsp;</td>
            <td width="52%">&nbsp;</td>
              </tr>
         </tr>
         <tr>
           <td height="31"align="center"><span class="style2"><strong>User Name </strong></span></td>
           <td><label>
             <input name="uname" type="text" id="uname" required />
           </label></td>
         </tr>
         <tr>
           <td height="44" align="center"><span class="style2"><strong>Password</strong></span></td>
           <td><label>
             <input name="password" type="password" id="password" required />
           </label></td>
         </tr>
         <tr>
           <td height="44" align="center"><span class="style2"><strong>CAPTCHA</strong></span></td>
           <td>
               <div class="captcha-container">
                   <div class="captcha-code"><?php echo $captcha_code; ?></div>
               </div>
               <input name="captcha" type="text" id="captcha" placeholder="Enter the code above" required />
           </td> 
         </tr>
         <tr>
           <td>&nbsp;</td>
           <td rowspan="2"><label>
             <input name="btn" type="submit" id="btn" value="Login" />
             <input type="reset" name="Submit2" value="Cancel" />
           </label></td>
         </tr>
  </table>
</form>
<div> &nbsp;</div>
<div id="footer"> copyrights & designedby@Tours & travels</div>
</body>
</html>