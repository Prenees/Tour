<?php
include("dbconnect.php");
session_start();
?>
<html>
<head>
<title>Tours & Travels</title>
<style>
/* Navbar Animation */
#navbar {
  padding: 25px;
  background: #00ffff;
  text-align: center;
  color:white;
  font-family: Arial;
  font-size: 35px;
  animation: fadeIn 1s ease-in-out;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-20px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Navigation Bar */
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: sticky;
  top: 0;
  z-index: 1000;
}

li { float: left; }

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  transition: 0.3s;
}
li a:hover { background-color: rgb(105, 166, 166); transform: scale(1.1); }

.active{
  background-color: rgb(105, 166, 166);
}

/* Background Animation */
#bg1 {
  padding: 150px;
  background: url("img/8.jpg") no-repeat center center/cover;
  border-radius: 10px;
  animation: zoomBackground 10s infinite alternate ease-in-out;
}
@keyframes zoomBackground {
  0% { transform: scale(1); }
  100% { transform: scale(1.05); }
}

/* Table Styling */
table {
  width: 90%;
  margin: auto;
  border-collapse: collapse;
}

td {
  padding: 12px;
  border: 1px solid #ddd;
  text-align: center;
}

/* Hover Animation for Table Rows */
tr:hover { background-color:rgb(165, 158, 171); transition: color 0.3s ease-in-out; }

/* Footer */
#footer {
  padding: 20px;
  background:#333;
  color:white;
  text-align: center;
  font-family: Arial;
  font-size: 15px;
  animation: fadeIn 1s ease-in-out;
}
</style>
</head>
<body>
<div id="navbar">Tours And Travels</div>
<ul> 
  <li><a href="#">&nbsp;</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="adminhome.php">Home Page</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="guide.php">Add Guide</a></li>
   <li><a href="#">&nbsp;</a></li>
  <li><a href="transopts.php">Add Transport</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewu.php">User Details</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewp.php">Packages</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a class="active" href="booking.php">Bookings</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="feedback1.php">Feedback Details</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="index.php">Logout</a></li>
</ul>

<div id="bg1"></div>

<table>
  <tr><td colspan="7" align="center"><strong>Packages Booking</strong></td></tr>
  <tr>
    <td><strong>Package Name</strong></td>
    <td><strong>Places</strong></td>
    <td><strong>User Name</strong></td>
    <td><strong>Number Of Persons</strong></td>
    <td><strong>Amount</strong></td>
    <td><strong>Status</strong></td>
  </tr>

  <?php
  $qry = mysqli_query($conn, "SELECT * FROM booking");
  while ($row = mysqli_fetch_array($qry)) {
    $pid = $row['pid'];
    $uid = $row['uid'];
    $qry1 = mysqli_query($conn, "SELECT * FROM package WHERE id='$pid'");
    $row1 = mysqli_fetch_array($qry1);
    $qry2 = mysqli_query($conn, "SELECT * FROM register WHERE id='$uid'");
    $row2 = mysqli_fetch_array($qry2);
  ?>
    <tr>
      <td><?php echo $row1['pname']; ?></td>
      <td><?php echo $row1['place']; ?></td>
      <td><?php echo $row2['name']; ?></td>
      <td><?php echo $row['np']; ?></td>
      <td><?php echo $row['amnt']; ?></td>
      <td>Booked</td>
    </tr>
  <?php } ?>
</table>

<table>
  <tr><td colspan="7" align="center"><strong>Vehicle Booking</strong></td></tr>
  <tr>
    <td><strong>Vehicle Name</strong></td>
    <td><strong>No Of Seats</strong></td>
    <td><strong>Vehicle Number</strong></td>
    <td><strong>Amount Per Day</strong></td>
    <td><strong>Start Date</strong></td>
    <td><strong>End Date</strong></td>
    <td><strong>Total Amount</strong></td>
    <td><strong>User ID</strong></td>
    <td><strong>Status</strong></td>
  </tr>

  <?php
  $qry = mysqli_query($conn, "SELECT * FROM book");
  while ($row = mysqli_fetch_array($qry)) {
    $gid = $row['rid'];
    $qry1 = mysqli_query($conn, "SELECT * FROM transport WHERE id='$gid'");
    $row1 = mysqli_fetch_array($qry1);
  ?>
    <tr>
      <td><?php echo $row1['vname']; ?></td>
      <td><?php echo $row1['seats']; ?></td>
      <td><?php echo $row1['vno']; ?></td>
      <td><?php echo $row1['amnt']; ?></td>
      <td><?php echo $row['sdate']; ?></td>
      <td><?php echo $row['edate']; ?></td>
      <td><?php echo $row['amnt']; ?></td>
      <td><?php echo $row['uid']; ?></td>
      <td>Booked</td>
    </tr>
  <?php } ?>


</body>
</html>

</table>

<div id="footer">Copyrights & Designed by Tours & Travels</div>
</body>
</html>