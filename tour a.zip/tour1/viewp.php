<?php
include("dbconnect.php");
session_start();
?>

<html>
<head>
<title>Tours & Travels</title>
<style>
/* Animated Navbar */
#navbar {
  padding: 20px;
  background: #00ffff;
  color: white;
  font-family: Arial;
  font-size: 35px;
  text-align: center;
  animation: fadeIn 3s ease-in-out;
}

/* Smooth Fade-In Effect */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-20px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Animated Footer */
#footer {
  border: 2px solid #888844;
  padding: 45px;
  background:#333;
  color:white;
  border-radius: 10px;
  text-align: center;
  font-family: Arial;
  font-size: 15px;
  animation: fadeIn 1s ease-in-out;
}

/* Stylish Navbar */
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #444;
  position: sticky;
  top: 0;
  z-index: 1000;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  transition: 0.3s;
}

li a:hover {
  background-color: rgb(105, 166, 166);
  transform: scale(1.1);
}
.active{
  background-color: rgb(105, 166, 166);
}

/* Animated Background */
#bg1 {
  padding: 150px;
  background: url("img/7.jpg") no-repeat center center/cover;
  border-radius: 10px;
  animation: zoomBackground 10s infinite alternate ease-in-out;
}

/* Background Zoom Effect */
@keyframes zoomBackground {
  0% { transform: scale(1); }
  100% { transform: scale(1.05); }
}

/* Table Styling */
table {
  width: 80%;
  margin: auto;
  border-collapse: collapse;
}

td {
  padding: 12px;
  border: 1px solid #ddd;
  text-align: center;
}

/* Table Row Hover Animation */
tr:hover {
  background-color:rgb(157, 211, 159);
  transition: color 0.3s ease-in-out;
}

/* Delete Button Animation */
.delete-btn {
  display: inline-block;
  padding: 8px 12px;
  background:#333;
  color: white;
  text-decoration: none;
  border-radius: 5px;
  transition: 0.3s;
}

.delete-btn:hover {
  background: #cc0000;
  transform: scale(1.1);
}
</style>
</head>

<body>
<div id="navbar"><p>Tours And Travels</p></div>

<ul>
<li><a href="#">&nbsp;</a></li>
<li><a href="#">&nbsp;</a></li>
<li><a href="#">&nbsp;</a></li>
<li><a href="#">&nbsp;</a></li>
  <li><a href="adminhome.php">Home Page</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="guide.php">Add Guide</a></li>
   <li><a href="#">&nbsp;</a></li>
  <li><a href="transopts.php">Add Transport</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewu.php">User Details</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a class="active" href="viewp.php">Packages</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="booking.php">Bookings</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="feedback1.php">Feedback Details</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="index.php">Logout</a></li>
</ul>

<div id="bg1"></div>

<table>
  <tr><td colspan="7" align="center"><strong>Packages Details</strong></td></tr>
  <tr>
    <td><strong>Package Name</strong></td>
    <td><strong>Places</strong></td>
    <td><strong>Number Of Days</strong></td>
    <td><strong>Package Price</strong></td>
    <td><strong>Actions</strong></td>
  </tr>

  <?php
  $qry = mysqli_query($conn, "SELECT * FROM package");
  while ($row = mysqli_fetch_array($qry)) {
  ?>
    <tr>
      <td><?php echo $row['pname']; ?></td>
      <td><?php echo $row['place']; ?></td>
      <td><?php echo $row['edate']; ?></td>
      <td><?php echo $row['package_price']; ?></td>
      <td><a href="viewp.php?act=del&pid=<?php echo $row['id']; ?>" class="delete-btn">Delete Package</a></td>
    </tr>
  <?php } ?>

</table>

<?php
// Delete Package
if (isset($_GET['act']) && $_GET['act'] == 'del') {
    if (isset($_GET['pid']) && !empty($_GET['pid'])) {
        $pid = mysqli_real_escape_string($conn, $_GET['pid']);
        $qry = mysqli_query($conn, "DELETE FROM package WHERE id='$pid'");

        if ($qry) {
            echo "<script>alert('Package deleted successfully'); window.location.href='viewp.php';</script>";
        } else {
            echo "<script>alert('Error deleting package');</script>";
        }
    }
}
?>

<div id="footer">Copyrights & Designed by Tours & Travels</div>

</body>
</html>
