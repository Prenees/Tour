<!DOCTYPE html>
<html>
<head>
<title>Tours & Travels</title>
<style>
#navbar
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Arial', sans-serif;
}

body {
    background-color:rgba(173, 173, 173, 0.62);
    color: #333;
    line-height: 1.6;
    padding: 20px;
}

.container {
    width: 90%;
    max-width: 1200px;
    margin: 0 auto;
    background: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Header */
#navbar {
    padding: 25px;
    background: #1e3c72;
    text-align: center;
    color: white;
    font-size: 35px;
    border-radius: 10px 10px 0 0;
}

/* Navigation */
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
    text-align: center;
    border-radius: 0 0 10px 10px;
}

li {
    display: inline;
    margin: 0 15px;
}

li a {
    color: white;
    text-decoration: none;
    padding: 14px 16px;
    font-size: 18px;
}

li a:hover {
    background-color: #003f7f;
    border-radius: 5px;
}

/* Hero Section */
#bg1 {
    padding: 180px;
    background: url("img/5.jpg") no-repeat center center;
    background-size: cover;
    border-radius: 10px;
    text-align: center;
    color:black;
    font-size: 35px;
    font-weight: bold;
}

/* Tour Cards */
#tour-images {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
    padding: 50px;
}

.tour-card {
    width: 300px;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    text-align: center;
    background: white;
}

.tour-card img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}

.tour-card p {
    background-color: #0056b3;
    color:white;
    padding: 15px;
    font-size: 18px;
    font-weight: bold;
    border-radius: 0 0 10px 10px;
}

.tour-card p a {
    color: white;
    text-decoration: none;
}

.tour-card p a:hover {
    text-decoration: underline;
}

/* Footer */
#footer {
    padding: 20px;
    background: #1e3c72;
    color: white;
    text-align: center;
    font-size: 16px;
    border-radius: 10px;
}
</style>
</head>
<body>

<div id="navbar"><p>Tours And Travels</p></div>

<ul>
  <li><a href="index.php">Home Page</a></li>
  <li><a href="admin.php">Admin Login</a></li>
  <li><a href="user.php">User Login</a></li>
  <li><a href="register.php">User Registration</a></li>
</ul>

<div id="bg1">Explore The World With Us</div>

<!-- Tour Destination Images Section -->
<div id="tour-images">
  <div class="tour-card">
    <img src="img/beach.jpg" alt="Beautiful Beach">
    <p><a style="text-decoration:none: color:white;" href="user.php">Relax on the Stunning Beaches</a></p>
  </div>
  <div class="tour-card">
    <img src="img/mountain.jpg" alt="Mountain Adventure">
    <p><a style="text-decoration:none: color:white;" href="user.php">Adventure in the Mountains</a></p>
  </div>
  <div class="tour-card">
    <img src="img/historical.jpg" alt="Historical Places">
    <p><a style="text-decoration:none: color:white;" href="user.php">Diccover Historical Wonders</a></p>
  </div>
  <div class="tour-card">
    <img src="img\night.jpg" alt="Historical Places">
    <p><a style="text-decoration:none: color:white;" href="user.php">Enjoy your Night</a></p>
  </div>
  
</div>
<div id="tour-images">
  <div class="tour-card">
    <img src="img/wildlife.jpg" alt="Beautiful Beach">
    <p><a style="text-decoration:none: color:white;" href="user.php">Wildlife Tours</a></p>
  </div>
  <div class="tour-card">
    <img src="img/HONEYMOON.jpg" alt="Mountain Adventure">
    <p><a style="text-decoration:none: color:white;" href="user.php">Honeymoon Packages</a></p>
  </div>
  <div class="tour-card">
    <img src="img/Indonesia.jpg" alt="Historical Places">
    <p><a style="text-decoration:none: color:white;" href="user.php">Adventure in the ocean</a></p>
  </div>
  <div class="tour-card">
    <img src="img/UAE.jpg" alt="Historical Places">
     <p><a style="text-decoration:none: color:white;" href="user.php">Speciality Tours</a></p>
  </div>
  
  
</div>

<div id="footer">© Copyrights & Designed by Tours & Travels</div>

</body>
</html>
