<?php
include 'dbconnect.php'; // Database connection

$sql = "SELECT id, uid, feedback FROM feedback ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<style>

body {
    font-family: Arial, sans-serif;
    background: #f4f4f4;
    text-align: center;
}

.title {
    animation: fadeIn 1s ease-in-out;
}

.feedback-table {
    width: 80%;
    margin: 20px auto;
    border-collapse: collapse;
    background: white;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    animation: slideUp 0.5s ease-in-out;
}

.feedback-table th, .feedback-table td {
    padding: 10px;
    border: 1px solid #ddd;
}

.delete-btn {
    display: inline-block;
    padding: 5px 10px;
    color: white;
    background: red;
    text-decoration: none;
    border-radius: 5px;
    transition: background 0.3s;
}

.delete-btn:hover {
    background: darkred;
}

/* Animations */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideUp {
    from { transform: translateY(20px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

</style>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Details</title>
    <link rel="stylesheet" href="styles.css"> <!-- External CSS -->
</head>
<body>
    <h2 class="title">Feedback Details</h2>
    <table border="1" class="feedback-table">
        <tr>
            <th>ID</th>
            <th>User ID</th>
            <th>Feedback</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr class="fade-in">
                <td><?php echo $row['id']; ?></td>
                <td><?php echo htmlspecialchars($row['uid']); ?></td>
                <td><?php echo htmlspecialchars($row['feedback']); ?></td>
                <td>
                    <a href="javascript:void(0);" class="delete-btn" data-id="<?php echo $row['id']; ?>">Delete</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <script>
        document.querySelectorAll(".delete-btn").forEach(button => {
            button.addEventListener("click", function() {
                let id = this.getAttribute("data-id");
                if (confirm("Are you sure you want to delete this feedback?")) {
                    window.location.href = "delete_feedback.php?id=" + id;
                }
            });
        });
    </script>
</body>
</html>
