<?php
session_start();
include("dbconnect.php");
extract($_POST);
$uid=$_SESSION['id'];
$rid=$_REQUEST['id'];
$amnt=$_REQUEST['amnt'];


	
	
			
	
	
	 function diff($date1, $date2) {
        $diff = abs(strtotime($date2) - strtotime($date1));

        $years = floor($diff / (365*60*60*24));
        $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
        $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24) / (60*60*24));

        return $days;
	
			
			}
		if(isset($_POST['btn']))
		{

		$qry3= mysqli_query($conn,"SELECT sdate,edate FROM book WHERE  rid='$rid' AND '$sdate' between sdate AND edate");
	
		$count=mysqli_num_rows($qry3);
		if($count==0){
	
		$d1 = $sdate;
    $d2 = $edate;
    $diff= diff($d1, $d2);

	$diff=$diff+1;
	$tamnt=$diff*$amnt;
$max_qry = mysqli_query($conn,"select max(id) from book");
		$max_row = mysqli_fetch_array($max_qry); 
		$id=$max_row['max(id)']+1;
$qry=mysqli_query($conn,"insert into book values('$id','$uid','$rid','$sdate','$edate','$amnt','$diff','$tamnt','1')");
if($qry)
{


	header("location:payment1.php?tmant=".$tamnt);


}
}
else
{
echo"<script> alert('This Vehicle already booked on this date')</script>";
}




   			
    }
	?>
<html>
<title>Tours & Travels</title>
<style>
#navbar {
  padding: 25px;
  background:#00ffff;
  background-size: 1420px  100px;
  text-align:center;
  text-decoration:blink;
  color:#4d4d00;
   font-family: Arial;
   font-size:35px;
}

p
{
	color:#4d4d00;
	text-align: center;
	text-transform: uppercase;
	 font-size:20px;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #888844;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}

#footer {
  border: 2px solid #888844;
  padding: 45px;
  background: #888844;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:15px;
}
#bg1 {

  padding:150px;
  background:url("images/4.png");
  background-repeat: no-repeat;  background-size: 100%  200px;
  border-radius:5px;
   border-radius:10px;
   font-size:35px;
}

</style>
</head>
<div id="navbar"><p>Tours And Travels </p></div>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	  <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	   <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	    <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a class="active" href="userhome.php">UserHome</a></li>
   <li><a href="#">&nbsp;</a></li>
  <li><a href="viewt.php">View Transports</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewbook.php">View Booking</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="index.php">LogOut</a></li>
</ul>
<div id="bg1"> </div>

		<form id="f1" name="f1" method="post" action="#"  >
  <table width="39%" height="245" border="0" align="center">
	<tr>
	<td colspan="2" align="center"><strong>Book Room</strong></td>
	</tr>
	<tr>
    <tr>
      <td width="46%" height="31">&nbsp;</td>
      <td width="54%">&nbsp;</td>
    </tr>
	 <tr>
      <td height="42">From </td>
      <td>
      		<input name="sdate" type="date" required>
      </td>
      
    </tr>	
	 
	  <tr>
      <td height="42">TO</td>
      <td>
      		<input name="edate" type="date" required>
      </td>
      
    </tr>	
	
	
	
  
	 <tr>
	 <td height="61">&nbsp;</td>
      <td><input name="btn" type="submit" id="btn" value="Submit" />
      <input type="reset" name="Submit2" value="Reset" /></td>
    </tr>
</table>
  
</form>

<div> &nbsp;</div>
<div id="footer"> copyrights & designedby@Tours & travels</div>