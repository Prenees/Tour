<?php
 	include("dbconnect.php");
	extract($_POST);
	session_start();
	 $uid=$_SESSION['id'];
	 $pid=$_REQUEST['pid'];
	echo $pp=$_GET['pp'];
	
	
	if(isset($_POST['btn']))
	{
	
	
	$amnt=$pp*$np;
	$gst=$amnt*0.05;
	$amnt1=$amnt+$gst;
		$qry=mysqli_query($conn,"insert into booking(uid,pid,np,status,amnt) values('$uid','$pid','$np','','$amnt1')");
		
		if($qry)
		{
		
		header("location:payment.php");
		}
		
		else
		{
		
		echo "<script>alert('failed')</script>";
		
		}	
	
	}

?>
<html>
<title>Tours & Travels</title>
<style>
#navbar {
  padding: 25px;
  background:#00ffff;
  background-size: 1420px  100px;
  text-align:center;
  text-decoration:blink;
  color:#4d4d00;
   font-family: Arial;
   font-size:35px;
}

p
{
	color:#4d4d00;
	text-align: center;
	text-transform: uppercase;
	 font-size:20px;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #888844;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}

#footer {
  border: 2px solid #888844;
  padding: 45px;
  background: #888844;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:15px;
}
#bg1 {

  padding:150px;
  background:url("img/6.jpg");
  background-repeat: no-repeat;  background-size: 100%  200px;
  border-radius:5px;
   border-radius:10px;
   font-size:35px;
}

</style>
</head>


<div id="navbar"><p>Tours And Travels </p></div>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	  <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	   <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	    <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a class="active" href="userhome.php">UserHome</a></li>
   <li><a href="#">&nbsp;</a></li>
  <li><a href="viewt.php">View Transports</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewbook.php">View Booking</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="index.php">LogOut</a></li>
</ul>
<div id="bg1"> </div>

		
		<form action="#" method="post">
		
			<table width="575" align="center">		
		<?php
		$qry=mysqli_query($conn,"select * from package where id='$pid'");
		$i=1;
		while($row=mysqli_fetch_array($qry))
		{
		?>

        <tr>
<td width="208" align="center">Pacakage Name</td>
		   <td width="190"><div align="center"><?php echo $row['pname'];?></div></td>
		   <td>&nbsp;</td>
		   </tr>
		   <tr>
		   <td align="center">Places</td>
			  <td><div align="center"><?php echo $row['place'];?></div></td>
			  <td>&nbsp;</td>
			  </tr>
			  <tr>
			   <td align="center">Dates</td>
			
			   <td width="161"><div align="center"><?php echo $row['edate'];?></div></td>
		      </tr>
			   <tr>
			   <td align="center">Price</td>
			   <td><div align="center"><?php echo $row['package_price'];?></div></td>
			   <td>&nbsp;</td>
			   </tr>
			   <tr>
			  <td align="center">Enter Number Of Persons</td>
			    <td><div align="center"><input type="text" name="np"></div></td>
				<td>&nbsp;</td>
			  </tr>
				<tr>
				 <tr>
			  <td align="center">&nbsp;</td>
			    <td><div align="center">&nbsp;</div></td>
				<td>&nbsp;</td>
			  </tr>
				
				  <td align="center"colspan="3"><input type="submit" name="btn"></td>
		 
        </tr>
		
        <?php
		}
		
		?>
		
</table>

</form>


<div> &nbsp;</div>
<div id="footer"> copyrights & designedby@Tours & travels</div>