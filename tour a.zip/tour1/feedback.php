<?php
include 'dbconnect.php'; // Database connection

// Handle feedback submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_feedback'])) {
    $uid = $_POST['uid'];
    $feedback = $_POST['feedback'];
    
    $sql = "INSERT INTO feedback (uid, feedback) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $uid, $feedback);
    
    if ($stmt->execute()) {
        echo "<div class='success-msg'>Feedback submitted successfully!</div>";
    } else {
        echo "<div class='error-msg'>Error: " . $stmt->error . "</div>";
    }
}

// Fetch and display feedback
$sql = "SELECT uid, feedback FROM feedback ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
        }
        .feedback-container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            animation: fadeIn 1s;
        }
        .feedback {
            background: #e3f2fd;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
            animation: slideIn 0.5s;
        }
        .success-msg, .error-msg {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            font-weight: bold;
        }
        .success-msg {
            background: #d4edda;
            color: #155724;
        }
        .error-msg {
            background: #f8d7da;
            color: #721c24;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideIn {
            from { transform: translateY(10px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        form {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        input, textarea, button {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
        }
        button {
            background: #007bff;
            color: white;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="feedback-container">
        <h2>User Feedback</h2>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <div class='feedback'>
                <strong>User ID: <?php echo htmlspecialchars($row['uid']); ?></strong>
                <p><?php echo htmlspecialchars($row['feedback']); ?></p>
            </div>
        <?php } ?>

        <!-- Feedback Form for Users -->
        <form method="POST">
            <label for="uid">User ID:</label>
            <input type="text" name="uid" required>
            <label for="feedback">Feedback:</label>
            <textarea name="feedback" required></textarea>
            <button type="submit" name="submit_feedback">Submit Feedback</button>
        </form>
    </div>
</body>
</html>

<!-- Admin Panel: Display All Feedback -->
<?php if (isset($_SESSION['adminhome']) && $_SESSION['adminhome'] == true) { ?>
    <div class="feedback-container">
        <h2>Admin Feedback Panel</h2>
        <?php
        $admin_sql = "SELECT * FROM feedback ORDER BY id DESC";
        $admin_result = $conn->query($admin_sql);
        while ($admin_row = $admin_result->fetch_assoc()) { ?>
            <div class='feedback'>
                <strong>User ID: <?php echo htmlspecialchars($admin_row['uid']); ?></strong>
                <p><?php echo htmlspecialchars($admin_row['feedback']); ?></p>
            </div>
        <?php } ?>
    </div>
<?php } ?>
