<?php
include("dbconnect.php");
session_start();
$uid = isset($_SESSION['id']) ? $_SESSION['id'] : null;

if (!$uid) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tours & Travels</title>
    <style>
        #navbar {
            padding: 15px;
            background: #00ffff;
            text-align: center;
            color: white;
            font-family: Arial;
            font-size: 35px;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
            position: sticky;
            top: 0;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color:white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color:rgb(105, 166, 166);
			color:white;
        }

        .active {
            background-color:rgb(105, 166, 166);
        }

        #footer {
            padding: 20px;
            background: #333;
            text-align: center;
            font-family: Arial;
            font-size: 15px;
            color: white;
            border-radius: 10px;
        }

        #bg1 {
            padding: 150px;
            background: url("img/7.jpg") no-repeat center;
            background-size: cover;
            border-radius: 10px;
            font-size: 35px;
        }

        table {
            width: 97%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        td, th {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
            color: #007bff;
        }

        a:hover {
            color:rgb(33, 46, 60);
        }
    </style>
</head>
<body>

<div id="navbar">
    <p>Tours And Travels</p>
</div>

<ul>
<li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	  <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	   <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	    <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
    <li><a href="userhome.php">User Home</a></li>
	<li><a href="#">&nbsp;</a></li>
    <li><a class="active" href="bookguide.php">View Guide</a></li>
	<li><a href="#">&nbsp;</a></li>
    <li><a href="viewt.php">View Transports</a></li>
	<li><a href="#">&nbsp;</a></li>
    <li><a href="viewbook.php">View Booking</a></li>
	<li><a href="#">&nbsp;</a></li>
	<li><a href="feedback.php">Feedback</a></li>
	<li><a href="#">&nbsp;</a></li>
    <li><a href="index.php">Logout</a></li>
</ul>

<div id="bg1"></div>

<table>
    <tr>
        <th>Id</th>
        <th>Guide Name</th>
        <th>Amount</th>
        <th>Address</th>
        <th>Places</th>
        <th>Description</th>
        <th>Book</th>
    </tr>

    <?php
    $qry = mysqli_query($conn, "SELECT * FROM guides");

    if ($qry) {
        while ($row = mysqli_fetch_assoc($qry)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['gname']) . "</td>";
            echo "<td>" . htmlspecialchars($row['amnt']) . "</td>";
            echo "<td>" . htmlspecialchars($row['address']) . "</td>";
            echo "<td>" . htmlspecialchars($row['place']) . "</td>";
            echo "<td>" . htmlspecialchars($row['des']) . "</td>";
            echo "<td><a href='bookg.php?gid=" . $row['id'] . "&gp=" . $row['amnt'] . "'>Book Guide</a></td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='7'>No guides available.</td></tr>";
    }
    ?>
</table>

<div id="footer">Copyrights & Designed by @Tours & Travels</div>

</body>
</html>
