<?php
 include("dbconnect.php");
extract($_POST);
session_start();
$uid=$_SESSION['id'];

$tamnt=$_REQUEST['tmant'];

if(isset($_POST['btn']))
{

		
?>
<script language="javascript">
	alert("Amount Transfer Successfull..");
	window.location.href="userhome.php";
	</script>
<?php
}
?>		
	
	
	
	<script>	  

	
 function cno()
{
  var cno=/^[0-9]{16}$/;
   if(document.f1.cno.value.search(cno)==-1)
    {
	 alert("enter correct Card no");
	 document.f1.cno.focus();
	 return false;
	 }
	} 
	
	
	
	 function cvv()
{
  var cvv=/^[0-9]{3}$/;
   if(document.f1.cvv.value.search(cvv)==-1)
    {
	 alert("enter correct Pin");
	 document.f1.cvv.focus();
	 return false;
	 }
	} 
	
	 
	function vali()
	{
	var cno=/^[0-9]{16}$/;
	var cvv=/^[0-9]{3}$/;
	 //var mesg=/^[a-zA_Z0-9]{10,300}$/;
   if(document.f1.cno.value.search(cno)==-1)
    {
	 alert("the card number Should be 16 degit");
	 document.f1.cno.focus();
	 return false;
	 }
	 	 
	 
	  else if(document.f1.cvv.value.search(cvv)==-1)
    {
	 alert("The Cvv number should be 3 degit");
	 document.f1.cvv.focus();
	 return false;
	 }
	 
	 
	 else
	 {
	 return true;
	 }
	}
	
</script>
	
	<html>
<title>Tours & Travels</title>
<style>
#navbar {
  padding: 25px;
  background:#00ffff;
  background-size: 1420px  100px;
  text-align:center;
  text-decoration:blink;
  color:white;
   font-family: Arial;
   font-size:35px;
}

p
{
	color:white;
	text-align: center;
	text-transform: uppercase;
	 font-size:20px;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: sticky; /* Safari */
  position: sticky;
  top: 0;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: rgb(105, 166, 166);
}

.active {
  background-color:rgb(105, 166, 166);
}

#footer {
  border: 2px solid #888844;
  padding: 45px;
  background: #333;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:15px;
}
#bg1 {

  padding:150px;
  background:url("img/payment.jpg");
  background-repeat: no-repeat;  background-size: 100%  200px;
  border-radius:5px;
   border-radius:10px;
   font-size:35px;
}

</style>
</head>
<div id="navbar"><p>Tours And Travels </p></div>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	  <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	   <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	    <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a class="active" href="userhome.php">UserHome</a></li>
   <li><a href="#">&nbsp;</a></li>
  <li><a href="viewt.php">View Transports</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewbook.php">View Booking</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="index.php">LogOut</a></li>
</ul>
<div id="bg1"> </div>


<div> &nbsp;</div>


	
		<form method="post" id="f1" name="f1" action="#"  onSubmit="return vali()">
	  <table width="50%" border="0" align="center">
        <tr>
          <td colspan="2"><span class="style1">Payment Mode.... </span></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><label>
            <input type="image" name="imageField" src="images/payment.png" />
          </label></td>
        </tr>
        <tr>
          <td width="35%"><span class="style4">Amount</span> </td>
		  <td> <?php echo $tamnt;?></td>
        </tr>
        <tr>
          <td height="33"><span class="style4">Enter Card Number </span></td>
          <td><input name="cno" type="text" id="cno" /></td>
        </tr>
        <tr>
          <td height="36"><span class="style4">CVV Number </span></td>
          <td><input name="cvv" type="password" id="cvv" /></td>
        </tr>
        <tr>
          <td><span class="style4">Card Name </span></td>
          <td><input name="cname" type="text" id="cname" required /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input name="btn" type="submit"value="Pay"  /></td>
        </tr>
      </table> 
  </form>
  
  
  
  
  
  
  
  <br>
		<br>
		<br>
		<br>
			<br>
		<br>
		<br />
		<br />
		<br />
		<br />


<br>
 
<br />
<br />
<br />
<div> &nbsp;</div>
<div id="footer">Designed By Admin</div>
