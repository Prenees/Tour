<?php
 	include("dbconnect.php");
	extract($_POST);
	session_start();
	

?>
<html>
<title>Tours & Travels</title>
<style>
#navbar {
  padding: 25px;
  background:#00ffff;
  background-size: 1420px  100px;
  text-align:center;
  text-decoration:blink;
  color:white;
   font-family: Arial;
   font-size:35px;
}

p
{
	color:white;
	text-align: center;
	text-transform: uppercase;
	 font-size:20px;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color:#333;
  position: sticky; /* Safari */
  position: sticky;
  top: 0;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: rgb(105, 166, 166);
}

.active {
  background-color: rgb(105, 166, 166);
}

#footer {
  border: 2px solid rgb(96, 105, 110);
  padding: 45px;
  background: #333;
  color:white;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:15px;
}
#bg1 {

  padding:150px;
  background:url("img/7.jpg");
  background-repeat: no-repeat;  background-size: 100%  200px;
  border-radius:5px;
   border-radius:10px;
   font-size:35px;
}
/* Table Styling */
table {
  width: 80%;
  margin: auto;
  border-collapse: collapse;
}

td {
  padding: 12px;
  border: 1px solid #ddd;
  text-align: center;
}

/* Table Row Hover Animation */
tr:hover {
  background-color:rgb(157, 211, 159);
  transition: color 0.3s ease-in-out;
}
</style>
</head>
<div id="navbar"><p>Tours And Travels </p></div>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	  <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	  <li><a  href="adminhome.php">Home Page</a></li>
   <li><a href="#">&nbsp;</a></li>
   <li><a href="guide.php">Add Guide</a></li>
   <li><a href="#">&nbsp;</a></li>
  <li><a href="transopts.php">Add Transopts</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a class="active" href="viewu.php">User Details</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="viewp.php">Packages Details</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="booking.php">Booking Details</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="feedback1.php">Feedback Details</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="index.php">LogOut</a></li>
</ul>
<div id="bg1"> </div>

			<table width="96%" align="center">
	<tr>
		<td colspan="10" align="center"><strong>User Details</strong></td>
		</tr>
		<tr>
		<td colspan="10" align="center"><strong>&nbsp;</strong></td>
		</tr>	
		    <tr>
          <td width="0%">&nbsp;</td>
           <td width="18%"><div align="center" class="style6"><strong>User Name</strong> </div></td>
		    <td width="15%"><div align="center" class="style6"><strong>Email</strong> </div></td>
			 <td width="12%"><div align="center" class="style6"><strong>Phone</strong> </div></td>
			  <td width="10%"><div align="center" class="style6"><strong>Gender</strong> </div></td>
			  <td width="13%"><div align="center" class="style6"><strong>Age</strong> </div></td>
			  <td width="16%"><div align="center" class="style6"><strong>Location</strong> </div></td>
		    <td width="12%"><div align="center" class="style6"><strong>Address</strong> </div></td>
        </tr>
		</form>
		<tr>
		<td colspan="10">&nbsp;</td>
		</tr>
		<?php
		$qry=mysqli_query($conn,"select * from register");
		$i=1;
		while($row=mysqli_fetch_array($qry))
		{
        
			?>
		
		<tr>
		 <td width="0%">&nbsp;</td>
		   <td><div align="center"><?php echo $row['name'];?></div></td>
			  <td><div align="center"><?php echo $row['email'];?></div></td>
			 <td><div align="center"><?php echo $row['phone'];?></div></td>
			   <td><div align="center"><?php echo $row['gender'];?></div></td>
			   <td><div align="center"><?php echo $row['age'];?></div></td>
			    <td><div align="center"><?php echo $row['location'];?></div></td>
			    <td><div align="center"><?php echo $row['address'];?></div></td>
			  <td width="2%"> </div></td>
		 
        </tr>
		
		
		 <tr>
		  	 	<td>&nbsp;</td>
		   		<td>&nbsp;</td>
				<td>&nbsp;</td>
			 	<td>&nbsp;</td>
			 	<td>&nbsp;</td>
			 	<td>&nbsp;</td>
				<td>&nbsp;</td>
		
		
		</tr>
		
        <?php
		$i++;
		}
		
		?>
				<tr>
		<td colspan="10" align="center">&nbsp;</td>
		</tr>
		
</table>







<div> &nbsp;</div>
<div id="footer"> copyrights & designedby@Tours & travels</div>