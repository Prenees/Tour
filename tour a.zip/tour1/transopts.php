<?php
 	include("dbconnect.php");
	extract($_POST);
	session_start();
if(isset($_POST['btn']))
{
	$max_qry = mysqli_query($conn,"select max(id) from transport");
	$max_row = mysqli_fetch_array($max_qry); 
	$id=$max_row['max(id)']+1;
$qry=mysqli_query($conn,"insert into transport values('$id','$vname','$seats','$vno','$amnt')");
if($qry)
{

echo "<script>alert('Data Save');</script>";
}
else
{
echo "<script>alert('Data Not Save');</script>";

}
}

?>
<html>
<title>Tours & Travels</title>
<style>
#navbar {
  padding: 25px;
  background:#00ffff;
  background-size: 1420px  100px;
  text-align:center;
  text-decoration:blink;
  color:#4d4d00;
   font-family: Arial;
   font-size:35px;
}

p
{
	color:white;
	text-align: center;
	text-transform: uppercase;
	 font-size:20px;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: sticky; /* Safari */
  position: sticky;
  top: 0;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color:rgb(105, 166, 166);;
}

.active {
  background-color:rgb(105, 166, 166);
}

#footer {
  border: 2px solid rgb(47, 47, 42);
  padding: 45px;
  background:#333;
  color:white;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:15px;
}
#bg1 {

  padding:150px;
  background:url("img/transportation.jpg");
  background-repeat: no-repeat;  background-size: 100%  300px;
  border-radius:5px;
   border-radius:10px;
   font-size:35px;
}
form {
    animation: fadeIn 2s ease-in-out;
}

@keyframes slideIn {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

form {
    animation: slideIn 1s ease-in-out;
}

</style>
</head>
<div id="navbar"><p>Tours And Travels </p></div>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	  <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	  <li><a  href="adminhome.php">Home Page</a></li>
   <li><a href="#">&nbsp;</a></li>
   <li><a href="guide.php">Add Guide</a></li>
   <li><a href="#">&nbsp;</a></li>
  <li><a class="active" href="transopts.php">Add Transopts</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewu.php">User Details</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="viewp.php">Packages Details</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="booking.php">Booking Details</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="feedback1.php">Feedback Details</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="index.php">LogOut</a></li>
</ul>
<div id="bg1"> </div>
<form id="form1" name="form1" method="post" action="">
	   <table width="46%" border="0" align="center">
         <tr>
           <td colspan="2" rowspan="1"><div align="center" class="style1"><strong><font size="+1">Add Vehicles</font> </div></td>
		 </tr>
			<tr>
		<td width="48%">&nbsp;</td>
		    <td width="52%">&nbsp;</td>
	  		</tr>
         </tr>
         <tr>
           <td height="31"align="center"><span class="style2"><strong>Vehicles Name </strong></span></td>
           <td><label>
             <input name="vname" type="text" id="vname" />
           </label></td>
         </tr>
         <tr>
           <td height="44" align="center"><span class="style2"><strong>No Of Seats </strong></span></td>
           <td><label>
             <input name="seats" type="text" id="seats" />
           </label></td>
         </tr>
		  <tr>
           <td height="44" align="center"><span class="style2"><strong>Vehicle No</strong></span></td>
           <td><label>
             <input name="vno" type="text" id="vno" />
           </label></td>
         </tr>
		  <tr>
           <td height="44" align="center"><span class="style2"><strong>Per Day Rent Amount</strong></span></td>
           <td><label>
             <input name="amnt" type="text" id="amnt" />
           </label></td>
         </tr>
		 
		    <tr>
           <td>&nbsp;</td>
           <td rowspan="2"><label>
             <input name="btn" type="submit" id="btn" value="add" />
             <input type="reset" name="Submit2" value="Cancel" />
           </label></td>
         </tr>
  </table>
</form>
<div> &nbsp;</div>
<div id="footer"> copyrights & designedby@Tours & travels</div>