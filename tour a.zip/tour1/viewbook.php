<?php
 	include("dbconnect.php");
	extract($_POST);
	session_start();
	 $uid=$_SESSION['id'];

?>
<html>
<title>Tours & Travels</title>
<style>
#navbar {
  padding: 25px;
  background:#00ffff;
  background-size: 1420px  100px;
  text-align:center;
  text-decoration:blink;
  color:white;
   font-family: Arial;
   font-size:35px;
}

p
{
	color:white;
	text-align: center;
	text-transform: uppercase;
	 font-size:20px;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: sticky; /* Safari */
  position: sticky;
  top: 0;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color:rgb(105, 166, 166);
}

.active {
  background-color: rgb(105, 166, 166);
}

#footer {
  border: 2px solid rgb(172, 172, 148);
  padding: 45px;
  background:#333;
  color:white;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:15px;
}
#bg1 {

  padding:150px;
  background:url("img/7.jpg");
  background-repeat: no-repeat;  background-size: 100%  200px;
  border-radius:5px;
   border-radius:10px;
   font-size:35px;
}

</style>
</head>
<div id="navbar"><p>Tours And Travels </p></div>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	  <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	   <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	    <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a  href="userhome.php">UserHome</a></li>
   <li><a href="#">&nbsp;</a></li>
   <li><a href="bookguide.php">View Guide</a></li>
  <li><a href="viewt.php">View Transports</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a class="active" href="viewbook.php">View Booking</a></li>
  <li><a href="#">&nbsp;</a></li>
  <li><a href="feedback.php">Feedback</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="index.php">LogOut</a></li>
</ul>
<div id="bg1"> </div>

			<table width="96%" align="center">
	<tr>
		<td colspan="10" align="center" class="style6"><strong>Packages Booking</strong> </td>
		</tr>	
		    <tr>
          <td width="0%">&nbsp;</td>
           <td width="11%"><div align="center" class="style6"><strong>Package Name</strong> </div></td>
		    <td width="12%"><div align="center" class="style6"><strong>Places</strong> </div></td>
			 <td width="8%"><div align="center" class="style6"><strong>GST</strong> </div></td>
			  <td width="11%"><div align="center" class="style6"><strong>End Date</strong> </div></td>
			  <td width="13%"><div align="center" class="style6"><strong>Pacakge Price</strong> </div></td>
			  <td width="16%"><div align="center" class="style6"><strong>Number Of persons</strong> </div></td>
		    <td width="12%"><div align="center" class="style6"><strong>Amount</strong> </div></td>
			  <td width="15%"><div align="center" class="style6"><strong>Status</strong> </div></td>
        </tr>
		</form>
		<tr>
		<td colspan="10">&nbsp;</td>
		</tr>
		<?php
		$qry=mysqli_query($conn,"select * from booking where uid='$uid'");
		$i=1;
		while($row=mysqli_fetch_array($qry))
		{
			$pid=$row['pid'];
			$qry1=mysqli_query($conn,"select * from package where id='$pid'");
			$row1=mysqli_fetch_array($qry1);
        
			?>
		
		
		<tr>
		 <td width="0%">&nbsp;</td>
		   <td><div align="center"><?php echo $row1['pname'];?></div></td>
			  <td><div align="center"><?php echo $row1['place'];?></div></td>
			 <td><div align="center">5%</div></td>
			   <td><div align="center"><?php echo $row1['edate'];?></div></td>
			   <td><div align="center"><?php echo $row1['package_price'];?></div></td>
			    <td><div align="center"><?php echo $row['np'];?></div></td>
			    <td><div align="center"><?php echo $row['amnt'];?></div></td>
				  <td><div align="center"><?php echo "booked"?></div></td>
		  <td width="2%"> </div></td>
		 
        </tr>
		
		
		 <tr>
		  	 	<td>&nbsp;</td>
		   		<td>&nbsp;</td>
				<td>&nbsp;</td>
			 	<td>&nbsp;</td>
			 	<td>&nbsp;</td>
			 	<td>&nbsp;</td>
				<td>&nbsp;</td>
		
		
		</tr>
		
        <?php
		$i++;
		}
		
		?>
				<tr>
		<td colspan="10" align="center">&nbsp;</td>
		</tr>
		
</table>








<table width="96%" align="center">
	<tr>
		<td colspan="10" align="center">Vehicle Booking</td>
		</tr>	
		    <tr>
          <td width="1%">&nbsp;</td>
           <td width="12%"><div align="center" class="style6"><strong>Vehicle Name</strong> </div></td>
		    <td width="20%"><div align="center" class="style6"><strong>No Of Seats</strong> </div></td>
			 <td width="15%"><div align="center" class="style6"><strong>Vehicle Number</strong> </div></td>
		    <td width="12%"><div align="center" class="style6"><strong>Amount Per Day</strong> </div></td>
			 <td width="11%"><div align="center" class="style6"><strong>Start Date</strong> </div></td>
			  <td width="15%"><div align="center" class="style6"><strong>End Date</strong> </div></td>
			    <td width="15%"><div align="center" class="style6"><strong>Total Amount</strong> </div></td>
			  <td width="12%"><div align="center" class="style6"><strong>Status</strong> </div></td>
        </tr>
		</form>
		<tr>
		<td colspan="10">&nbsp;</td>
		</tr>
		<?php
		$qry=mysqli_query($conn,"select * from book where uid='$uid'");
		$i=1;
		while($row=mysqli_fetch_array($qry))
		{
			$gid=$row['rid'];
			$qry1=mysqli_query($conn,"select * from transport where id='$gid'");
			$row1=mysqli_fetch_array($qry1);
        
			?>
		
		
		<tr>
		 <td width="1%">&nbsp;</td>
		   <td><div align="center"><?php echo $row1['vname'];?></div></td>
			  <td><div align="center"><?php echo $row1['seats'];?></div></td>
			 <td><div align="center"><?php echo $row1['vno'];?></div></td>
			   <td><div align="center"><?php echo $row1['amnt'];?></div></td>
			   <td><div align="center"><?php echo $row['sdate'];?></div></td>
			    <td><div align="center"><?php echo $row['edate'];?></div></td>
				  <td><div align="center"><?php echo $row['tamnt'];?></div></td>
				  <td><div align="center"><?php echo "booked"?></div></td>
		  <td width="2%"> </div></td>
		 
        </tr>
		
		
		 <tr>
		  	 	<td>&nbsp;</td>
		   		<td>&nbsp;</td>
				<td>&nbsp;</td>
			 	<td>&nbsp;</td>
			 	<td>&nbsp;</td>
			 	<td>&nbsp;</td>
				<td>&nbsp;</td>
		
		
		</tr>
		
        <?php
		$i++;
		}
		
		?>
				<tr>
		<td colspan="10" align="center">&nbsp;</td>
		</tr>
		
</table>







<div> &nbsp;</div>
<div id="footer"> copyrights & designedby@Tours & travels</div>