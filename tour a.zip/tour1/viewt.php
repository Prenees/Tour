<?php
 	include("dbconnect.php");
	extract($_POST);
	session_start();

?>
<html>
<title>Tours & Travels</title>
<style>
#navbar {
  padding: 25px;
  background:#00ffff;
  background-size: 1420px  100px;
  text-align:center;
  text-decoration:blink;
  color:white;
   font-family: Arial;
   font-size:35px;
}

p
{
	color:#4d4d00;
	text-align: center;
	text-transform: uppercase;
	 font-size:20px;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: sticky; /* Safari */
  position: sticky;
  top: 0;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: rgb(105, 166, 166);
}

.active {
  background-color: rgb(105, 166, 166);
}

#footer {
  border: 2px solid #888844;
  padding: 45px;
  background: #333;
  color:white;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:15px;
}
#bg1 {

  padding:150px;
  background:url("img/5.jpg");
  background-repeat: no-repeat;  background-size: 100%  200px;
  border-radius:5px;
   border-radius:10px;
   font-size:35px;
}

</style>
</head>
<div id="navbar"><p>Tours And Travels </p></div>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	  <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	   <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	    <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a  href="userhome.php">UserHome</a></li>
   <li><a href="#">&nbsp;</a></li>
   <li><a href="bookguide.php">View Guide</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a class="active" href="viewt.php">View Transports</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewbook.php">View Booking</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a href="feedback.php">Feedback Details</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="index.php">LogOut</a></li>
</ul>
<div id="bg1"> </div>

		<table width="80%" align="center">
	<tr>
		<td colspan="7" align="center">Transports  Details</td>
		</tr>
		<tr>
		<td colspan="7">&nbsp;</td>
		</tr>	
		    <tr>
          <td width="10%">&nbsp;</td>
           <td width="16%"><div align="center" class="style6"><strong>Vehicle Id</strong> </div></td>
		   <td width="19%"><div align="center" class="style6"><strong>Vehicle Name</strong> </div></td>
		    <td width="16%"><div align="center" class="style6"><strong>No Of Seats</strong> </div></td>
			 <td width="17%"><div align="center" class="style6"><strong>Vehicle No</strong> </div></td>
			  <td width="17%"><div align="center" class="style6"><strong>Amount Per Day</strong> </div></td>
			  <td width="17%"><div align="center" class="style6"><strong>Book</strong> </div></td>
	      </tr>
		</form>
		<tr>
		<td colspan="7">&nbsp;</td>
		</tr>
		<?php
		$qry=mysqli_query($conn,"select * from transport");
		$i=1;
		while($row=mysqli_fetch_array($qry))
		{
			       
			?>
		
		
		<tr>
		 <td width="10%">&nbsp;</td>
		   <td><div align="center"><?php echo $row['id'];?></div></td>
			  <td><div align="center"><?php echo $row['vname'];?></div></td>
			 <td><div align="center"><?php echo $row['seats'];?></div></td>
			   <td><div align="center"><?php echo $row['vno'];?></div></td>
			   <td><div align="center"><?php echo $row['amnt'];?></div></td>
  <td><div align="center"><a href="book1.php?id=<?php echo $row['id'];?>&amnt=<?php echo $row['amnt'];?>">Book Transport</a></div></td>		 
        </tr>
		
		
		 <tr>
		  	 	<td>&nbsp;</td>
		   		<td>&nbsp;</td>
				<td>&nbsp;</td>
			 	<td>&nbsp;</td>
			 	<td>&nbsp;</td>
			 	<td>&nbsp;</td>
				<td>&nbsp;</td>
		
		
		</tr>
		
        <?php
		$i++;
		}
		
			
		?>
				<tr>
		<td colspan="5" align="center">&nbsp;</td>
		</tr>
		
</table>

<div> &nbsp;</div>
<div id="footer"> copyrights & designedby@Tours & travels</div>