<?php
include("dbconnect.php");
session_start();
extract($_POST);
$uid=$_SESSION['id'];
$qry=mysqli_query($conn,"select * from booking where uid='$uid' && status='' ");
$row=mysqli_fetch_assoc($qry);
 $amnt=$row['amnt'];

if(isset($_POST['btn']))
{
$qry1=mysqli_query($conn,"update booking set status='1' where uid='$uid'");
	if($qry){?>
		 <script> alert('payment success')
window.location.href=("userhome.php");</script>
<?php }  } ?>
<html>
<title>Tours & Travels</title>
<style>
#navbar {
  padding: 25px;
  background:#00ffff;
  background-size: 1420px  100px;
  text-align:center;
  text-decoration:blink;
  color:white;
   font-family: Arial;
   font-size:35px;
}

p
{
	color:white;
	text-align: center;
	text-transform: uppercase;
	 font-size:20px;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color:#333;
  position: sticky; /* Safari */
  position: sticky;
  top: 0;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color:rgb(105, 166, 166);
}

.active {
  background-color: rgb(105, 166, 166);
}

#footer {
  border: 2px solid rgb(108, 108, 103);
  padding: 45px;
  background: #333;
  color:white;
  background-repeat: no-repeat;
  background-size: 1420px  100px;
  border-radius:10px;
  text-align:center;
  text-decoration:blink;
   font-family: Arial;
   font-size:15px;
}
#bg1 {

  padding:150px;
  background:url("img/payment.jpg");
  background-repeat: no-repeat;  background-size: 100%  200px;
  border-radius:5px;
   border-radius:10px;
   font-size:35px;
}

</style>
</head>
<div id="navbar"><p>Tours And Travels </p></div>
<ul>
	 <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	  <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	   <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
	    <li><a href="#">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a></li>
  <li><a class="active" href="userhome.php">UserHome</a></li>
   <li><a href="#">&nbsp;</a></li>
  <li><a href="viewt.php">View Transports</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a href="viewbook.php">View Booking</a></li>  <li><a href="#">&nbsp;</a></li>
  <li><a href="#">&nbsp;</a></li>
   <li><a href="index.php">LogOut</a></li>
</ul>
<div id="bg1"> </div>




<form method="post" action="#">
	  <table width="50%" border="0" align="center">
        <tr>
          <td colspan="2"><span class="style1">Payment Mode.... </span></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><label>
            <input type="image" name="imageField" src="images/payment.png" />
          </label></td>
        </tr>
        <tr>
          <td width="35%"><span class="style4">Amount</span> </td>
		  <td> <?php echo $amnt;?></td>
        </tr>
        <tr>
          <td height="33"><span class="style4">Enter Card Number </span></td>
          <td><input name="cno" type="text" id="cno" /></td>
        </tr>
        <tr>
          <td height="36"><span class="style4">CVV Number </span></td>
          <td><input name="cvv" type="password" id="cvv" /></td>
        </tr>
        <tr>
          <td><span class="style4">Card Name </span></td>
          <td><input name="cname" type="text" id="cname" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input name="btn" type="submit"value="Pay" /></td>
        </tr>
      </table> 
  </form>  
<div> &nbsp;</div>
<div id="footer"> copyrights & designedby@Tours & travels</div>